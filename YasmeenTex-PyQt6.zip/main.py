import sys
import os
from pathlib import Path

# Set Qt plugin path for WebEngine
if getattr(sys, 'frozen', False):
    # Running as PyInstaller bundle
    qt_plugin_path = os.path.join(sys._MEIPASS, 'PyQt6', 'Qt6', 'plugins')
    if os.path.exists(qt_plugin_path):
        os.environ['QT_PLUGIN_PATH'] = qt_plugin_path
    
    # Set WebEngine resources path
    webengine_path = os.path.join(sys._MEIPASS, 'PyQt6', 'Qt6', 'resources')
    if os.path.exists(webengine_path):
        os.environ['QT_WEBENGINE_RESOURCES_PATH'] = webengine_path

from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QIcon, QPixmap
from main_window import MainWindow

def main():
    """Main entry point for the application."""
    app = QApplication(sys.argv)
    app.setStyle('Fusion')

    # Optional: Add custom styling
    app.setStyleSheet("""
        QMainWindow, QDialog {
            background-color: #f5f5f5;
        }
        QPushButton {
            background-color: #0078d4;
            color: white;
            border: none;
            padding: 8px 8px;
            border-radius: 4px;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #106ebe;
        }
        QPushButton:pressed {
            background-color: #005a9e;
        }
    """)

    app.setWindowIcon(QIcon("YasmeenTex.svg"))
    
    main_window = MainWindow()
    
    main_window.show()
    
    main_window.showMaximized()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
